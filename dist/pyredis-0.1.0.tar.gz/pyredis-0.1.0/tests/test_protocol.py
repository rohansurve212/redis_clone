# Redis Protocol:
# Spec: https://redis.io/docs/latest/develop/reference/protocol-spec/

# For Simple Strings, the first byte of the reply is "+"     "+OK\r\n"
# For Errors, the first byte of the reply is "-"             "-Error message\r\n"
# For Integers, the first byte of the reply is ":"           ":[<+|->]<value>\r\n"
# For Bulk Strings, the first byte of the reply is "$"       "$<length>\r\n<data>\r\n"
# For Arrays, the first byte of the reply is "*"             "*<number-of-elements>\r\n<element-1>...<element-n>"


# We will need a module to extract messages from the stream.
# When we read from the network we will get:
# 1. A partial message.
# 2. A whole message.
# 3. A whole message, followed by either 1 or 2.
# We will need to remove parsed bytes from the stream.
from pyredis.protocol import BulkString, Error, parse_frame, SimpleString

import pytest


@pytest.mark.parametrize("buffer, expected", [
    # Simple String
    (b"+OK", (None, 0)),
    (b"+OK\r\n", (SimpleString("OK"), 5)),
    (b"+OK\r\n+Part", (SimpleString("OK"), 5)),
    (b"+OK\r\n+Second Message\r\n", (SimpleString("OK"), 5)),
    # Error
    (b"-Err", (None, 0)),
    (b"-Error\r\n", (Error("Error"), 8)),
    (b"-Error\r\n-Part Error", (Error("Error"), 8)),
    # BulkString
    (b"$5\r\nPart", (None, 0)),
    (b"$11\r\nBulk String\r\n", (BulkString("Bulk String"), 18)),
    (b"$8\r\nBulk Str\r\n$+OK", (BulkString("Bulk Str"), 14)),
])
def test_parse_frame(buffer, expected):
    got = parse_frame(buffer)
    assert got[0] == expected[0]
    assert got[1] == expected[1]


def test_serialise_simple():
    val = SimpleString("OK")
    expected = b"+OK\r\n"
    got = val.encode()
    assert got == expected